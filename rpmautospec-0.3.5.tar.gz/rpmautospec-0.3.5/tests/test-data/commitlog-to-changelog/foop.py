#!/usr/bin/env python3

import re
import sys
from enum import Enum, auto
from textwrap import TextWrapper
from typing import List

ELLIPSIS_RE = re.compile(r"^(?P<ellipsis>\.{3,}|…+)\s*(?P<rest>.*)$")
LINEWRAPPER = TextWrapper(width=75, subsequent_indent="  ")


class ParseState(int, Enum):
    before_subject = auto()
    subject = auto()
    before_body = auto()
    in_continuation = auto()
    body = auto()


def commitlog_to_changelog(commitlog: str) -> str:
    changelog_items_lines: List[List[str]] = [[]]

    state: ParseState = ParseState.before_subject

    for line in commitlog.split("\n"):
        line = line.replace("%", "%%").strip()

        # print(f">>> {state.name}: '{line}'")

        if state == ParseState.before_subject:
            if not line:
                # fast-forward to subject if it's not right at the beginning
                # (unlikely)
                continue

            state = ParseState.subject
            # strip off leading dash from subject, if any
            if line.startswith("-"):
                line = line[1:].lstrip()

        if state == ParseState.subject:
            if line:
                changelog_items_lines[0].append(line)
            else:
                state = ParseState.before_body
            continue

        if state == ParseState.before_body:
            if not line:
                # fast-forward to body
                continue

            match = ELLIPSIS_RE.match(line)
            if match:
                state = ParseState.in_continuation
                changelog_items_lines[0].append(match.group("rest"))
                continue
            else:
                if not line.startswith("-"):
                    # bail out
                    break
                state = ParseState.body

        if state == ParseState.in_continuation:
            if not line or line.startswith("-"):
                state = ParseState.body
            else:
                changelog_items_lines[0].append(line)
                continue

        # state == ParseState.body

        if not line:
            # outta here, we're done
            break

        if line.startswith("-"):
            line = line[1:].lstrip()
            changelog_items_lines.append([])

        changelog_items_lines[-1].append(line)

    # Now changelog_items_lines should contain one list per changelog item,
    # containing all lines (stripped of prefixes and such).

    changelog_items = [
        LINEWRAPPER.fill("- " + " ".join(lines))
        for lines in changelog_items_lines
    ]

    return "\n".join(changelog_items)


def main():
    for fname in sys.argv[1:]:
        with open(fname, "r") as fp:
            commitlog = fp.read()

        print("* Day 01 Month 1234 Blub Blub <blub@blublub.com>")
        print("=" * 40)
        print(commitlog_to_changelog(commitlog))
        print("=" * 40)


if __name__ == "__main__":
    main()
